<!DOCTYPE html>
<html>
<head>
    <title>OSA Registration Form Submission</title>
</head>
<body>
<p><strong>Name:</strong> {{ $data['name'] }}</p>
<p><strong>Father's Name:</strong> {{ $data['father_name'] }}</p>
<p><strong>Subject:</strong> {{ $data['subject'] }}</p>
<p><strong>Passing Year:</strong> {{ $data['passing_year'] }}</p>
<p><strong>Qualification:</strong> {{ $data['qualification'] }}</p>
<p><strong>Contact Number:</strong> {{ $data['contact_number'] }}</p>
<p><strong>Whatsapp Number:</strong> {{ $data['whatsappNumber'] }}</p>
<p><strong>Email:</strong> {{ $data['email'] }}</p>
<p><strong>Permanent Address:</strong> {{ $data['permanent_address'] }}</p>
<p><strong>Employment Status:</strong> {{ $data['Employment_status'] }}</p>
<p><strong>Place of Posting:</strong> {{ $data['place_of_posting'] }}</p>
</body>
</html>
