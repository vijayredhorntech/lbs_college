<!DOCTYPE html>
<html>
<head>
    <title>Contact Form Submission</title>
</head>
<body>
<p><strong>Name:</strong> {{ $name }}</p>
<p><strong>Email:</strong> {{ $email }}</p>
<p><strong>Number:</strong> {{ $number }}</p>
<p><strong>Message:</strong> {{ $messageText }}</p>
</body>
</html>
